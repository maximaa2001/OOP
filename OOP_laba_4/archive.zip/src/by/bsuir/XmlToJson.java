package by.bsuir;

import java.io.File;
import java.io.IOException;

public interface XmlToJson {
    void xtj(File file) throws IOException;
}
